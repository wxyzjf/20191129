YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY


INSERT /*+ APPEND */ INTO MIG_ADW.B_NORTON_RPT_001
(
   CUST_NUM
  ,SUBR_NUM
  ,BILL_SERV_CD
  ,START_DATE
  ,END_DATE
  ,NUM_ID
  ,USER_ID
  ,CAMP_ID
  ,PRODUCT_SKU
  ,SUBSCRIP_START_DATE
  ,SUBSCRIP_CANCEL_DATE
  ,SUBSCRIP_CUR_MON
  ,DEMO_UNIT
  ,CANCEL_UNIT
  ,BILLABLE_UNIT
  ,CREATE_TS
  ,REFRESH_TS
)
select 
   a.ACCOUNT
  ,a.MSISDN
  ,b.BILL_SERV_CD
  ,d.START_DATE
  ,d.END_DATE
  ,row_number() over (order by a.USER_ID) as NUM_ID
  ,a.USER_ID
  ,c.CAMP_ID
  ,c.PRODUCT_SKU
  ,b.BILL_START_DATE
  ,b.BILL_END_DATE
  ,case when trunc(d.SUBR_SW_ON_DATE,'mm') = trunc(SYSDATE,'mm')
        then d.SUBR_SW_ON_DATE
   else to_date('19000101','YYYYMMDD')
   end as SUBSCRIP_CUR_MON
  ,' ' as DEMO_UNIT
  ,case when trunc(d.SUBR_SW_OFF_DATE,'mm') = trunc(SYSDATE,'mm')
        then 'Y'
   else 'N'
   end as CANCEL_UNIT
  ,' ' as BILLABLE_UNIT
  ,sysdate
  ,sysdate
from MIG_ADW.NORTON_ACR_MAP a 
left outer join prd_adw.bill_servs b
on a.ACCOUNT = b.CUST_NUM and a.MSISDN = b.SUBR_NUM
   and b.BILL_END_DATE >= &rpt_s_date
   and b.BILL_START_DATE <= &rpt_e_date
left outer join MIG_ADW.NORTON_CAMP_ID_MAP c
on b.BILL_SERV_CD = c.BILL_CODE
   and &rpt_e_date between c.START_DATE and c.END_DATE
left outer join prd_adw.subr_info_hist d
on a.ACCOUNT = d.CUST_NUM and a.MSISDN = d.SUBR_NUM
   and &rpt_e_date between c.START_DATE and c.END_DATE
where c.CAMP_ID is not null;





INSERT /*+ APPEND */ INTO MIG_ADW.B_NORTON_RPT_002
(
   MONTH
  ,CAMP_ID
  ,PRODUCT_SKU
  ,DESCRIPTION
  ,BILLABLE_UNITS
  ,UNIT_PRICE
  ,SUB_TTL
  ,CREATE_TS
  ,REFRESH_TS
)
select
   trunc(SYSDATE,'mm') as MONTH
  ,a.CAMP_ID
  ,a.PRODUCT_SKU
  ,' ' as DESCRIPTION
  ,b.BILLABLE_UNITS
  ,a.UNIT_PRICE
  ,b.BILLABLE_UNITS * a.UNIT_PRICE as SUB_TTL
  ,sysdate
  ,sysdate
from MIG_ADW.NORTON_CAMP_ID_MAP a 
left outer join (select CAMP_ID,count(CAMP_ID) as BILLABLE_UNITS 
                 from MIG_ADW.B_NORTON_RPT_001 group by CAMP_ID)b
on a.CAMP_ID = b.CAMP_ID;











TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT


select 
   row_number() over (order by a.USER_ID) as NUM_ID
  ,a.ACCOUNT
  ,a.MSISDN
  ,a.USER_ID
  ,b.BILL_SERV_CD
  ,b.BILL_START_DATE
  ,b.BILL_END_DATE
  ,c.CAMP_ID
  ,c.PRODUCT_SKU
  ,d.START_DATE
  ,d.END_DATE
  ,d.SUBR_SW_ON_DATE
  ,case when trunc(d.SUBR_SW_ON_DATE,'mm') = trunc(SYSDATE,'mm')
        then d.SUBR_SW_ON_DATE
   else to_date('19000101','YYYYMMDD')
   end as SUBSCRIP_CUR_MON
  ,d.SUBR_SW_OFF_DATE
  ,case when trunc(d.SUBR_SW_OFF_DATE,'mm') = trunc(SYSDATE,'mm')
        then 'Y'
   else 'N'
   end as CANCEL_UNIT
from MIG_ADW.NORTON_ACR_MAP a 
left outer join prd_adw.bill_servs b
on a.ACCOUNT = b.CUST_NUM and a.MSISDN = b.SUBR_NUM
left outer join MIG_ADW.NORTON_CAMP_ID_MAP c
on b.BILL_SERV_CD = c.BILL_CODE 
left outer join prd_adw.subr_info_hist d
on a.ACCOUNT = d.CUST_NUM and a.MSISDN = d.SUBR_NUM
where c.CAMP_ID is not null;



select START_DATE,SUBR_SW_ON_DATE,SUBR_SW_OFF_DATE,SUBR_STAT_CD,IMSI,SIM,END_DATE 
from prd_adw.subr_info_hist where cust_num = '10452679' and subr_num = '63213572';


select CUST_NUM,SUBR_NUM,BILL_SERV_CD,BILL_START_DATE,BILL_END_DATE from prd_adw.bill_servs 
where cust_num = '10452679' and subr_num = '63213572' 
and BILL_SERV_CD in ('NSF01','NSS01','NSV01','NSP01','NSP02');
select* from prd_adw.bill_servs 
where cust_num = '10452679' and subr_num = '63213572' 
and BILL_SERV_CD in ('NSF01','NSS01','NSV01','NSP01','NSP02');



































